export function Coordenates(){

    const API_URL = 'https://api.mapbox.com/geocoding/v5';
    const API_KEY = 'pk.eyJ1Ijoic2VyZ2lvbWF4bHVpcyIsImEiOiJja3MwYTc4ZnIwa2V5Mm9ydzU0ejl3N3IxIn0.daibp8Mw_htYUb95Wf3zPw';

    const doRequest = (url) => {
        const promisseCallback = (resolve, reject) => {
          axios.get(url).then((result)=> {
            resolve(result.data);
          }).catch(reject);
        };
        return new Promise(promisseCallback);
      }
      
      const getApiUrl = (address) => {
        return `${API_URL}?key=${API_KEY}&address=${encodeURI(address)}`;
      }
      
      const address = '368 Broadway, New York, NY 10013, USA';
      
      (async () => {
        const apiUrl = getApiUrl(address);
        const data = await doRequest(apiUrl);
        
        if (!data || data.error_message) {
          const message = (data && data.error_message) ? data.error_message : 'Api Error';
          console.log(message);
          return;
        }

        console.log(data.results[0].geometry.location);
    })();

}
