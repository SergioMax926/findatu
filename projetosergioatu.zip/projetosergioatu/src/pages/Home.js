import React, { useRef, useEffect, useState } from "react";
import mapboxgl from "!mapbox-gl"; // eslint-disable-line import/no-webpack-loader-syntax
import { css } from "@emotion/css";

import $ from "jquery";

import { stores } from "services/geojson";

import {AiOutlineMenu} from "react-icons/ai";

import Input from "components/Input";

import ImgSearch from "../assets/searchIconRed.png";
import ImgMenu from "../assets/red-menu-icon.png";



mapboxgl.accessToken =
  "pk.eyJ1Ijoic2VyZ2lvbWF4bHVpcyIsImEiOiJja3MwYTc4ZnIwa2V5Mm9ydzU0ejl3N3IxIn0.daibp8Mw_htYUb95Wf3zPw";

export default function Home() {

  const styleMap = "mapbox://styles/mapbox/streets-v11"

  const mapContainer = useRef(null);
  const map = useRef(null);
  const [lng, setLng] = useState(-59.97929218985215);
  const [lat, setLat] = useState(-3.1343502420060987);
  const [zoom, setZoom] = useState(14);

  useEffect(() => {
    if (map.current) return; // initialize map only once
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: styleMap,
      center: [lng, lat],
      zoom: zoom,
    });
  });

  useEffect(() => {
    if (!map.current) return; // wait for map to initialize
    map.current.on("move", () => {
      setLng(map.current.getCenter().lng.toFixed(4));
      setLat(map.current.getCenter().lat.toFixed(4));
      setZoom(map.current.getZoom().toFixed(2));
    });
  });

  useEffect(() => {
    map.current.on('load', () => {
      map.current.addSource('places', {
        type: 'geojson',
        data: stores
      });
    });
  });//fim useEffect

  useEffect(() => {
    for (const feature of stores.features) {
      const el = document.createElement('div');
      el.className = 'marker';
      new mapboxgl.Marker(el).setLngLat(feature.geometry.coordinates).addTo(map.current);
    }
  })



  return (
    <div>

      <div className="elements">
      <div id="divBusca">
          <input type="text" id="txtBusca" placeholder="Buscar"
            className={css`
              width: 300px;
            `}
          />
        </div>

      </div>
        
      <div ref={mapContainer} className="map-container" />
    </div>
  )
}